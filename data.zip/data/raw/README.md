# Raw Data

This folder contains sample raw AoT (Array of Things) traces.  

## Contents
- **sample_raw_trace.csv**  
  - Example raw trace for **node `001e0610ee36`** on **2020-01-12**.  
  - Includes multiple sensor types (e.g., `hih6130`, `htu21d`, `co`) and parameters (`humidity`, `temperature`, `concentration`).  
  - Time resolution: **10-minute intervals**, with multiple entries per timestamp (one per sensor/parameter).  
  - Purpose: Demonstrates the structure and format of raw AoT data without including the full dataset.  

## Full Dataset
- The complete raw traces are very large (~1.2 GB, 30-second sampling across multiple nodes and sensors).  
- Due to size constraints, they are **not included in this repository**.  
- Full raw data can be queried directly from the Waggle repository using the notebook in  
  [`/notebooks/02_query_waggle.ipynb`](../../notebooks/02_query_waggle.ipynb).  

## Notes
- This sample is provided to **demonstrate the structure of raw AoT data**.  
- Full analyses should be performed on the complete dataset, which can be accessed via Waggle.  
