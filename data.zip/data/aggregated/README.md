# Aggregated Data

This folder contains aggregated versions of the Array of Things (AoT) sensor data at different temporal resolutions.  
These files were generated from raw Waggle traces using the aggregation scripts in [`/scripts/aggregation`](../../scripts/aggregation).  

## Contents
- **aot_aggregated_10min.csv**  
  - Aggregated sensor readings at **10-minute intervals**.  
  - Includes multiple nodes and sensors (temperature, humidity, pressure, pollutant concentrations).  
  - Useful for fine-grained analysis of short-term variations.  

- **aot_aggregated_1hour.csv**  
  - Aggregated sensor readings at **1-hour intervals**.  
  - Same set of nodes and sensors as the 10-minute file.  
  - Useful for long-term trends and stability analysis.  

## Notes
- Each file has the following schema:  
  - `timestamp` – UTC timestamp of the aggregate  
  - `node_id` – AoT node identifier  
  - `sensor` – sensor type (e.g., `htu21d`, `hih6130`, `co`)  
  - `parameter` – measurement parameter (e.g., `humidity`, `temperature`, `concentration`)  
  - `value_hrf` – aggregated value (mean over the interval)  

- The **30-minute aggregation** used in some analyses is not stored here, but can be reproduced using the same scripts.  

- These files are **examples of the aggregation pipeline outputs**. For reproducibility, users are encouraged to query the raw Waggle traces and regenerate aggregates with the provided code.  
